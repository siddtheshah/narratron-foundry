# Narratron Buddy - Foundry VTT Module

This folder contains the official Foundry VTT module for Narratron Buddy. It adds a GM control and keybinding that display Narratron's OBS Canvas view (`/obs`) in a floating panel for every connected player.

## Installation into Foundry VTT

In Foundry VTT, open **Add-on Modules**, click **Install Module**, and paste this URL into **Manifest URL**:

`https://github.com/siddtheshah/narratron-foundry/releases/latest/download/module.json`

For a manual installation, download `module.zip` from the latest GitHub release and extract it to your Foundry VTT User Data directory under `Data/modules/narratron`:

1. The module directory is located at:
   - **Windows**: `%LOCALAPPDATA%\FoundryVTT\Data\modules\narratron`
   - **macOS**: `~/Library/Application Support/FoundryVTT/Data/modules/narratron`
   - **Linux**: `~/.local/share/FoundryVTT/Data/modules/narratron`

2. Launch or restart Foundry VTT.
3. In Foundry VTT, go to **Game Settings** -> **Manage Modules**, find **Narratron Buddy Integration**, and enable it.
4. In **Module Settings**, as GM, set the shared Narratron OBS URL.
5. Open any scene in your world. As the GM, you will see a TV icon (`fas fa-tv`) in the left-side Scene Controls panel (under Token controls).
6. Click the TV icon, or press **Alt+O**, to toggle the Narratron OBS canvas overlay for every connected player. The keybinding can be changed in **Configure Controls**.

## Configuration & Audio Settings

In Foundry VTT: **Game Settings** -> **Configure Settings** -> **Module Settings**:
- **Narratron OBS URL**: Set the full direct URL for the OBS view. This is a GM-managed world setting and is loaded by every player, so it may include a theater join key only when your world users are trusted. The URL must be reachable from every player's browser; do not use `localhost` unless every player is running Narratron locally.
- **Enable Background Audio Sync**: Includes Narratron's selected background playlist in the OBS view embedded by Foundry VTT. The setting is enabled by default.
- **Audio Volume**: Controls the Narratron playlist volume in the Foundry overlay (default: `0.8`).

The GM controls whether the overlay is visible. Connected players render their own local instance automatically, and players joining while it is enabled also see it. Players can hide their own view with its close button (or **Alt+O**) without affecting anyone else, and use **Alt+O** to rejoin while the GM is still sharing it. After upgrading from a prior version, enter the OBS URL again because it has moved from a client setting to a world setting.

The Narratron view is a floating panel: drag its title bar to move it and use the lower-right corner to resize it. Each user’s panel size and position are saved locally. Hiding the panel pauses Narratron’s embedded music; reopening it resumes the active playlist.

## Streaming audio

The `/obs` page now plays the active Narratron background playlist as well as rendering the visuals. In OBS, enable audio capture for its Narratron Browser Source (the exact option name varies by OBS version) so the page audio is included in the stream/mixer. The page has no player UI. When previewing it in a normal browser, its autoplay policy may require one click on the canvas before sound can begin; OBS Browser Source normally permits autoplay. The Foundry overlay passes its **Enable Background Audio Sync** setting to the same page; set it off if music should stay out of the Foundry client.

## Publishing to the Foundry package repository

Create the version tag and GitHub release first, attaching `module.json` and `module.zip`. The download URL in `module.json` must point to that version's `module.zip` asset.

Then validate the release with Foundry's Package Release API:

```powershell
pwsh ./publish/publish-foundry.ps1 -ReleaseToken 'YOUR_PACKAGE_RELEASE_TOKEN'
```

After the dry run succeeds, publish the package release with:

```powershell
pwsh ./publish/publish-foundry.ps1 -ReleaseToken 'YOUR_PACKAGE_RELEASE_TOKEN' -Publish
```

The publish command always repeats the dry-run validation before making changes. Never commit the release token to the repository. Be aware that command-line arguments may be saved in shell history or visible to local process-inspection tools.
